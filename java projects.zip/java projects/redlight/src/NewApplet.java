/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

/**
 *
 * @author satellite
 */
public class NewApplet extends Applet {
int i=0;
Timer ob;
    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    public void init() {
         ob = new Timer(1000, new ActionListener()
        {
            public void actionPerformed(ActionEvent obb)
            {
                repaint();
            }
        });
        ob.start();
        
        
        
        // TODO start asynchronous download of heavy resources
    }
    public void paint(Graphics g)
    {i++;
                if(i==1)
                {   g.setColor(Color.red);
                   g.fillRect(100, 100, 100, 100);
                    g.setColor(Color.white);
                   g.fillRect(100, 300, 100, 100);
                   g.setColor(Color.white);
                   g.fillRect(100, 500, 100, 100);
                   ob.setDelay(5000);
                }
                
                else if(i==2)
                {
                    g.setColor(Color.white);
                   g.fillRect(100, 100, 100, 100);
                    g.setColor(Color.yellow);
                   g.fillRect(100, 300, 100, 100);
                   g.setColor(Color.white);
                   g.fillRect(100, 500, 100, 100);
                     ob.setDelay(10000);
                }
                else if(i==3)
                {
                     g.setColor(Color.white);
                   g.fillRect(100, 100, 100, 100);
                    g.setColor(Color.white);
                   g.fillRect(300, 100, 100, 100);
                   g.setColor(Color.green);
                   g.fillRect(100, 500, 100, 100);
                     ob.setDelay(5000);
                    i=0;
                }
    // TODO overwrite start(), stop() and destroy() methods
}
}