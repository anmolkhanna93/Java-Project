/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package login1;

/**
 *
 * @author Ashish
 */
public class Login1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new A().setVisible(true);
    }
}
