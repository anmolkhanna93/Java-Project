/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * room.java
 *
 * Created on 6 Sep, 2012, 8:23:42 PM
 */

package hotel;

import javax.swing.JOptionPane;
import java.sql.*;
/**
 *
 * @author Hitanshu
 */
public class room extends javax.swing.JFrame {
Connection con=null;
Statement stmt=null;
ResultSet rs=null;

    int a1;
    public room(int a) {
        a1=a;

        initComponents();
    if(a1==1)
    {
        lbloccupied.setVisible(false);
        optno.setVisible(false);
        optyes.setVisible(false);
        lblalloted.setVisible(false);
        txtalloted.setVisible(false);
    }
        if(a1==2)
        {
         
         lbloccupied.setVisible(false);
        optno.setVisible(false);
        optyes.setVisible(false);
        lblalloted.setVisible(false);
        txtalloted.setVisible(false);
        }



    }

        @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        lblroomno = new javax.swing.JLabel();
        lblroomtype = new javax.swing.JLabel();
        lbloccupied = new javax.swing.JLabel();
        lblalloted = new javax.swing.JLabel();
        txtroomno = new javax.swing.JTextField();
        txtroomtype = new javax.swing.JTextField();
        optyes = new javax.swing.JRadioButton();
        optno = new javax.swing.JRadioButton();
        txtalloted = new javax.swing.JTextField();
        cmdconfirm = new javax.swing.JButton();
        cmdreset = new javax.swing.JButton();

        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        lblroomno.setText("ROOM NO.");

        lblroomtype.setText("ROOM TYPE");

        lbloccupied.setText("OCCUPIED");

        lblalloted.setText("ALLOTED TO");

        txtroomno.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtroomnoKeyReleased(evt);
            }
        });

        buttonGroup1.add(optyes);
        optyes.setText("YES");

        buttonGroup1.add(optno);
        optno.setText("NO");

        cmdconfirm.setText("CONFIRM");
        cmdconfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdconfirmActionPerformed(evt);
            }
        });

        cmdreset.setText("RESET");
        cmdreset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdresetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblroomno)
                            .addComponent(lblroomtype)
                            .addComponent(lbloccupied)
                            .addComponent(lblalloted))
                        .addGap(46, 46, 46)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(optyes)
                                .addGap(18, 18, 18)
                                .addComponent(optno))
                            .addComponent(txtroomtype, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtroomno, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtalloted)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(cmdconfirm)
                        .addGap(61, 61, 61)
                        .addComponent(cmdreset)))
                .addContainerGap(112, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblroomno)
                    .addComponent(txtroomno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblroomtype)
                    .addComponent(txtroomtype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbloccupied)
                    .addComponent(optyes)
                    .addComponent(optno))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblalloted)
                    .addComponent(txtalloted, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmdconfirm)
                    .addComponent(cmdreset))
                .addContainerGap(67, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
    }//GEN-LAST:event_formWindowActivated

    private void cmdresetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdresetActionPerformed
txtalloted.setText(null);
txtroomno.setText(null);
txtroomtype.setText(null);
}//GEN-LAST:event_cmdresetActionPerformed

    private void txtroomnoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtroomnoKeyReleased
        char a=evt.getKeyChar();

if(a>='0' && a<='9')
{
//JOptionPane.showMessageDialog(null, a);
}
        else
        {
        txtroomno.setText(null);

        }
    }//GEN-LAST:event_txtroomnoKeyReleased

    private void cmdconfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdconfirmActionPerformed
        int roomno;
roomno=Integer.parseInt(txtroomno.getText());
if(roomno>9999||roomno<1000)
{
    txtroomno.setText(null);
    JOptionPane.showMessageDialog(null, "ENTER FOUR DIGIT ROOM NUMBER ONLY");
}
if(a1==1)
{
      try{
        Class.forName("java.sql.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vinayak","root","123456");



        String query;
        query="insert into room values('"+ txtroomno.getText()+"','"+txtroomtype.getText()+"','no','');";
        //query="insert into employee values("+"'"+txtname.getText()+"'"+","+"'"+txtage.getText()+"'"+","+"'"+txtemployeeid.getText()"'"+","+"'"+txtdesignation.getText()+"')";
       stmt=con.createStatement();
       stmt.executeUpdate(query);
        }
        catch(Exception ee)
        {
        JOptionPane.showMessageDialog(null, ee);
        }
    }//GEN-LAST:event_cmdconfirmActionPerformed
    if(a1==2)
    {
        
            try{
        String query;
                Class.forName("java.sql.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vinayak","root","123456");
        query="update room set roomtype='"+txtroomtype.getText()+"'where roomno='"+txtroomno.getText()+"';";
       stmt=con.createStatement();
       stmt.executeUpdate(query);
        JOptionPane.showMessageDialog(null,"room type updated");
            }
        catch(Exception ee)
        {
        JOptionPane.showMessageDialog(null, ee);
        }


       
        }
    }

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton cmdconfirm;
    private javax.swing.JButton cmdreset;
    private javax.swing.JLabel lblalloted;
    private javax.swing.JLabel lbloccupied;
    private javax.swing.JLabel lblroomno;
    private javax.swing.JLabel lblroomtype;
    private javax.swing.JRadioButton optno;
    private javax.swing.JRadioButton optyes;
    private javax.swing.JTextField txtalloted;
    private javax.swing.JTextField txtroomno;
    private javax.swing.JTextField txtroomtype;
    // End of variables declaration//GEN-END:variables

}
